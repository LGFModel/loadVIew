//
//  GFAddLoadView.h
//  demo
//
//  Created by 李国峰 on 16/7/22.
//  Copyright © 2016年 李国峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GFAddLoadView : UIView
- (void)timer:(float)timer alpha:(float)alpha color:(UIColor *)color lineWidth:(CGFloat)lineWidth;

@end
